function addAppletFromFixture(fixture){
		document.getElementById("applets").innerHTML = fixture
}