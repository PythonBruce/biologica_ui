#!/bin/bash

node_modules/karma/bin/karma start test/karma.models-e2e.conf.js
